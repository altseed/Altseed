﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Effekseer.GUI.Component
{
	class Colors
	{
		public static System.Drawing.Color EditedFloat = System.Drawing.Color.FromArgb(200, 230, 200);

		public static System.Drawing.Color EditingFloat = System.Drawing.Color.FromArgb(170, 200, 170);

		public static System.Drawing.Color EditedInt = System.Drawing.Color.FromArgb(230, 200, 200);

		public static System.Drawing.Color EditingInt = System.Drawing.Color.FromArgb(200, 170, 170);

		public static System.Drawing.Color Disable = System.Drawing.Color.FromArgb(200, 200, 200);

		public static System.Drawing.Color EditedString = System.Drawing.Color.FromArgb(230, 230, 230);
		public static System.Drawing.Color EditingString = System.Drawing.Color.FromArgb(200, 200, 200);
	}
}

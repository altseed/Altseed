﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Effekseer.Script
{
	public enum ScriptPosition
	{ 
		Internal,
		External,
	}
}


#ifndef	__SOUND_H__
#define	__SOUND_H__

#include "../Effekseer/Effekseer.h"

void InitSound(  void* handle1, void* handle2 );

void TermSound();

#endif

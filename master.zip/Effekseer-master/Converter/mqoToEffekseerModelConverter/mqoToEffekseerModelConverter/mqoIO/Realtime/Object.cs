﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mqoToEffekseerModelConverter.mqoIO.Realtime
{
	public class Object
	{
		public string Name = string.Empty;

		public Vertex[] Vertexes = new Vertex[0];

		public Face[] Faces = new Face[0];
	}
}

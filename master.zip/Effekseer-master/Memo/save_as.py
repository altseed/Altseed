
UniqueName = "Save2"
Author = "ShimepiSawada"
Title = "Save2"
Description = "Des"

def Call():
	print "Call2"
